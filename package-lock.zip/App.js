import React from 'react';
import { StatusBar } from 'expo-status-bar';
import { NavigationContainer } from '@react-navigation/native';
import { Provider as PaperProvider } from 'react-native-paper';
import { AuthProvider } from './src/context/AuthContext';
import { AlertProvider } from './src/context/AlertContext';
import { UserProvider } from './src/context/UserContext';
import AppNavigator from './src/navigation/AppNavigator';
import { theme } from './src/utils/Colors';

export default function App() {
  return (
    <PaperProvider theme={theme}>
      <AuthProvider>
        <UserProvider>
          <AlertProvider>
            <NavigationContainer>
              <StatusBar style="light" backgroundColor="#6366f1" />
              <AppNavigator />
            </NavigationContainer>
          </AlertProvider>
        </UserProvider>
      </AuthProvider>
    </PaperProvider>
  );
}


