import React, { useState, useEffect, useContext } from 'react';
import {
  View,
  ScrollView,
  StyleSheet,
  RefreshControl,
  Alert,
  Dimensions
} from 'react-native';
import {
  Text,
  Card,
  FAB,
  Portal,
  Modal,
  Snackbar
} from 'react-native-paper';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';

import { AuthContext } from '../context/AuthContext';
import { AlertContext } from '../context/AlertContext';
import AlertCard from '../components/alerts/AlertCard';
import EmergencyAlertDialog from '../components/alerts/EmergencyAlertDialog';
import ProfileCard from '../components/profile/ProfileCard';
import { Colors } from '../utils/Colors';
import { formatBloodType } from '../utils/Constants';
import AlertService from '../services/AlertService';

const { width } = Dimensions.get('window');

const HomeScreen = ({ navigation }) => {
  const { user } = useContext(AuthContext);
  const { alerts, refreshAlerts } = useContext(AlertContext);
  
  const [refreshing, setRefreshing] = useState(false);
  const [showEmergencyDialog, setShowEmergencyDialog] = useState(false);
  const [snackbarVisible, setSnackbarVisible] = useState(false);
  const [snackbarMessage, setSnackbarMessage] = useState('');

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      await refreshAlerts();
    } catch (error) {
      console.error('Error loading data:', error);
      const msg = error?.message || 'Error loading data. Please try again.';
      showSnackbar(msg);
    }
  };

  const onRefresh = async () => {
    setRefreshing(true);
    await loadData();
    setRefreshing(false);
  };

  const handleEmergencyResponse = async (alertId, response) => {
    try {
      await AlertService.respondToAlert(alertId, user.id, response);
      showSnackbar(`Response "${response}" submitted successfully!`);
      await refreshAlerts();
    } catch (error) {
      console.error('Error responding to alert:', error);
      const msg = error?.message || 'Error submitting response. Please try again.';
      showSnackbar(msg);
    }
  };

  const showSnackbar = (message) => {
    setSnackbarMessage(message);
    setSnackbarVisible(true);
  };

  const activeAlerts = alerts.filter(alert => alert.status === 'ACTIVE');
  const canCreateAlerts = user?.role === 'ADMIN' || user?.role === 'STAFF';

  return (
    <View style={styles.container}>
      <ScrollView
        style={styles.scrollView}
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={onRefresh} />
        }
        showsVerticalScrollIndicator={false}
      >
        {/* Welcome Header */}
        <LinearGradient
          colors={[Colors.primary, Colors.primaryDark]}
          style={styles.headerGradient}
        >
          <ProfileCard user={user} compact />
        </LinearGradient>

        {/* Emergency Alerts Section */}
        <View style={styles.alertsSection}>
          <View style={styles.sectionHeader}>
            <Ionicons name="warning" size={24} color={Colors.error} />
            <Text variant="headlineSmall" style={styles.sectionTitle}>
              Active Emergency Alerts
            </Text>
            {activeAlerts.length > 0 && (
              <View style={styles.badge}>
                <Text style={styles.badgeText}>{activeAlerts.length}</Text>
              </View>
            )}
          </View>

          {activeAlerts.length === 0 ? (
            <Card style={styles.emptyCard}>
              <Card.Content style={styles.emptyContent}>
                <Ionicons name="checkmark-circle" size={48} color={Colors.success} />
                <Text variant="titleMedium" style={styles.emptyTitle}>
                  No Active Alerts
                </Text>
                <Text variant="bodyMedium" style={styles.emptySubtitle}>
                  All emergency requests have been fulfilled
                </Text>
              </Card.Content>
            </Card>
          ) : (
            activeAlerts.map((alert) => (
              <AlertCard
                key={alert.id}
                alert={alert}
                onRespond={handleEmergencyResponse}
                currentUser={user}
              />
            ))
          )}
        </View>

        {/* Quick Stats */}
        <View style={styles.statsSection}>
          <Text variant="titleLarge" style={styles.sectionTitle}>
            Quick Stats
          </Text>
          <View style={styles.statsGrid}>
            <Card style={styles.statCard}>
              <Card.Content style={styles.statContent}>
                <Text variant="headlineMedium" style={[styles.statNumber, { color: Colors.primary }]}>
                  {user?.totalDonations || 0}
                </Text>
                <Text variant="bodySmall" style={styles.statLabel}>
                  Total Donations
                </Text>
              </Card.Content>
            </Card>
            
            <Card style={styles.statCard}>
              <Card.Content style={styles.statContent}>
                <Text variant="headlineMedium" style={[styles.statNumber, { color: Colors.success }]}>
                  Active
                </Text>
                <Text variant="bodySmall" style={styles.statLabel}>
                  Status
                </Text>
              </Card.Content>
            </Card>
          </View>
        </View>

        {/* Bottom spacing for FAB */}
        <View style={styles.bottomSpacing} />
      </ScrollView>

      {/* Floating Action Button for Staff */}
      {canCreateAlerts && (
        <Portal>
          <FAB
            icon="plus"
            style={styles.fab}
            onPress={() => setShowEmergencyDialog(true)}
            label="Create Alert"
          />
        </Portal>
      )}

      {/* Emergency Alert Creation Dialog */}
      <Portal>
        <Modal
          visible={showEmergencyDialog}
          onDismiss={() => setShowEmergencyDialog(false)}
          contentContainerStyle={styles.modalContainer}
        >
          <EmergencyAlertDialog
            visible={showEmergencyDialog}
            onDismiss={() => setShowEmergencyDialog(false)}
            onSuccess={(message) => {
              showSnackbar(message);
              refreshAlerts();
            }}
          />
        </Modal>
      </Portal>

      {/* Snackbar */}
      <Snackbar
        visible={snackbarVisible}
        onDismiss={() => setSnackbarVisible(false)}
        duration={3000}
        style={styles.snackbar}
      >
        {snackbarMessage}
      </Snackbar>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.gray[50],
  },
  scrollView: {
    flex: 1,
  },
  headerGradient: {
    paddingHorizontal: 16,
    paddingVertical: 20,
    borderBottomLeftRadius: 20,
    borderBottomRightRadius: 20,
  },
  alertsSection: {
    padding: 16,
  },
  sectionHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 16,
  },
  sectionTitle: {
    marginLeft: 8,
    flex: 1,
    fontWeight: 'bold',
  },
  badge: {
    backgroundColor: Colors.error,
    borderRadius: 12,
    paddingHorizontal: 8,
    paddingVertical: 4,
    minWidth: 24,
    alignItems: 'center',
  },
  badgeText: {
    color: Colors.white,
    fontSize: 12,
    fontWeight: 'bold',
  },
  emptyCard: {
    marginVertical: 8,
  },
  emptyContent: {
    alignItems: 'center',
    paddingVertical: 32,
  },
  emptyTitle: {
    marginTop: 16,
    marginBottom: 8,
    textAlign: 'center',
  },
  emptySubtitle: {
    textAlign: 'center',
    color: Colors.gray[600],
  },
  statsSection: {
    padding: 16,
  },
  statsGrid: {
    flexDirection: 'row',
    gap: 12,
    marginTop: 12,
  },
  statCard: {
    flex: 1,
  },
  statContent: {
    alignItems: 'center',
    paddingVertical: 16,
  },
  statNumber: {
    fontWeight: 'bold',
  },
  statLabel: {
    marginTop: 4,
    color: Colors.gray[600],
  },
  bottomSpacing: {
    height: 100,
  },
  fab: {
    position: 'absolute',
    margin: 16,
    right: 0,
    bottom: 0,
    backgroundColor: Colors.error,
  },
  modalContainer: {
    backgroundColor: Colors.white,
    margin: 20,
    borderRadius: 8,
    maxHeight: '80%',
  },
  snackbar: {
    backgroundColor: Colors.gray[800],
  },
});

export default HomeScreen;


