import React, { useState, useContext } from 'react';
import {
  View,
  ScrollView,
  StyleSheet,
  Alert
} from 'react-native';
import {
  Text,
  Card,
  Button,
  Avatar,
  List,
  Portal,
  Modal,
  Divider
} from 'react-native-paper';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';

import { AuthContext } from '../context/AuthContext';
import DonorRegistrationDialog from '../components/profile/DonorRegistrationDialog';
import StatsCard from '../components/profile/StatsCard';
import { Colors, getBloodTypeColor } from '../utils/Colors';
import { formatBloodType, formatDate } from '../utils/Constants';
import AuthService from '../services/AuthService';

const ProfileScreen = ({ navigation }) => {
  const { user, logout, updateUser } = useContext(AuthContext);
  const [showEditDialog, setShowEditDialog] = useState(false);

  const handleLogout = () => {
    Alert.alert(
      'Logout',
      'Are you sure you want to logout?',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Logout',
          style: 'destructive',
          onPress: async () => {
            try {
              await AuthService.logout();
              logout();
            } catch (error) {
              console.error('Logout error:', error);
            }
          }
        }
      ]
    );
  };

  const handleUpdateProfile = (updatedData) => {
    updateUser(updatedData);
    setShowEditDialog(false);
  };

  if (!user) {
    return (
      <View style={styles.container}>
        <Text variant="titleLarge">Loading...</Text>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <ScrollView showsVerticalScrollIndicator={false}>
        {/* Profile Header */}
        <LinearGradient
          colors={[Colors.primary, Colors.primaryDark]}
          style={styles.headerGradient}
        >
          <View style={styles.profileHeader}>
            <Avatar.Icon
              size={80}
              icon="water"
              style={[styles.profileAvatar, { backgroundColor: getBloodTypeColor(user.bloodType) }]}
            />
            <View style={styles.profileInfo}>
              <Text variant="headlineSmall" style={styles.userName}>
                {user.name}
              </Text>
              <Text variant="titleMedium" style={styles.bloodType}>
                {formatBloodType(user.bloodType)}
              </Text>
              <Text variant="bodyMedium" style={styles.userRole}>
                {user.role}
              </Text>
            </View>
          </View>
        </LinearGradient>

        {/* Stats Section */}
        <View style={styles.statsSection}>
          <StatsCard
            totalDonations={user.totalDonations || 0}
            lastDonationDate={user.lastDonationDate}
            eligibilityStatus={user.eligibilityStatus || 'ELIGIBLE'}
          />
        </View>

        {/* Contact Information */}
        <Card style={styles.infoCard}>
          <Card.Title title="Contact Information" left={(props) => <Ionicons name="person" size={24} color={Colors.primary} />} />
          <Card.Content>
            <List.Item
              title="Phone Number"
              description={user.phone}
              left={(props) => <List.Icon icon="phone" />}
            />
            {user.email && (
              <List.Item
                title="Email"
                description={user.email}
                left={(props) => <List.Icon icon="email" />}
              />
            )}
            {user.address && (
              <List.Item
                title="Address"
                description={user.address}
                left={(props) => <List.Icon icon="map-marker" />}
              />
            )}
          </Card.Content>
        </Card>

        {/* Personal Information */}
        <Card style={styles.infoCard}>
          <Card.Title title="Personal Information" left={(props) => <Ionicons name="information-circle" size={24} color={Colors.primary} />} />
          <Card.Content>
            <List.Item
              title="Age"
              description={`${user.age} years old`}
              left={(props) => <List.Icon icon="calendar" />}
            />
            <List.Item
              title="Gender"
              description={user.gender}
              left={(props) => <List.Icon icon="human-male-female" />}
            />
            {user.weight && (
              <List.Item
                title="Weight"
                description={`${user.weight} kg`}
                left={(props) => <List.Icon icon="scale" />}
              />
            )}
            <List.Item
              title="Member Since"
              description={formatDate(user.createdAt)}
              left={(props) => <List.Icon icon="clock" />}
            />
          </Card.Content>
        </Card>

        {/* Actions */}
        <Card style={styles.actionsCard}>
          <Card.Content>
            <Button
              mode="outlined"
              onPress={() => setShowEditDialog(true)}
              style={styles.actionButton}
              icon="pencil"
            >
              Update Profile
            </Button>
            
            <Button
              mode="outlined"
              onPress={() => navigation.navigate('DonationHistory')}
              style={styles.actionButton}
              icon="history"
            >
              Donation History
            </Button>
            
            <Button
              mode="outlined"
              onPress={() => navigation.navigate('Settings')}
              style={styles.actionButton}
              icon="cog"
            >
              Settings
            </Button>
            
            <Divider style={styles.divider} />
            
            <Button
              mode="contained"
              onPress={handleLogout}
              style={[styles.actionButton, styles.logoutButton]}
              buttonColor={Colors.error}
              icon="logout"
            >
              Logout
            </Button>
          </Card.Content>
        </Card>

        {/* Bottom spacing */}
        <View style={styles.bottomSpacing} />
      </ScrollView>

      {/* Edit Profile Modal */}
      <Portal>
        <Modal
          visible={showEditDialog}
          onDismiss={() => setShowEditDialog(false)}
          contentContainerStyle={styles.modalContainer}
        >
          <DonorRegistrationDialog
            visible={showEditDialog}
            onDismiss={() => setShowEditDialog(false)}
            onSuccess={handleUpdateProfile}
            initialData={user}
            isEditing={true}
          />
        </Modal>
      </Portal>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.gray[50],
  },
  headerGradient: {
    paddingHorizontal: 20,
    paddingVertical: 32,
    borderBottomLeftRadius: 24,
    borderBottomRightRadius: 24,
  },
  profileHeader: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  profileAvatar: {
    marginRight: 20,
  },
  profileInfo: {
    flex: 1,
  },
  userName: {
    color: Colors.white,
    fontWeight: 'bold',
    marginBottom: 4,
  },
  bloodType: {
    color: Colors.white,
    marginBottom: 4,
  },
  userRole: {
    color: Colors.white,
    opacity: 0.8,
    textTransform: 'capitalize',
  },
  statsSection: {
    padding: 16,
  },
  infoCard: {
    margin: 16,
    marginTop: 0,
  },
  actionsCard: {
    margin: 16,
    marginTop: 0,
  },
  actionButton: {
    marginVertical: 4,
  },
  logoutButton: {
    marginTop: 8,
  },
  divider: {
    marginVertical: 16,
  },
  bottomSpacing: {
    height: 32,
  },
  modalContainer: {
    backgroundColor: Colors.white,
    margin: 20,
    borderRadius: 12,
    maxHeight: '80%',
  },
});

export default ProfileScreen;


