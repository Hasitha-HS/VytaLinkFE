import ApiService from './ApiService';

class DonorService {
  // Register new donor
  async registerDonor(donorData) {
    try {
      const payload = {
        name: donorData.name,
        age: parseInt(donorData.age),
        gender: donorData.gender,
        bloodType: donorData.bloodType,
        phone: donorData.phone,
        email: donorData.email,
        address: donorData.address,
        weight: donorData.weight ? parseFloat(donorData.weight) : null,
        fcmToken: donorData.fcmToken
      };
      return await ApiService.post('/donors/register', payload);
    } catch (error) {
      console.error('Error registering donor:', error);
      throw error;
    }
  }

  // Get all donors
  async getAllDonors() {
    try {
      return await ApiService.get('/donors');
    } catch (error) {
      console.error('Error fetching all donors:', error);
      throw error;
    }
  }

  // Get donor by ID
  async getDonorById(donorId) {
    try {
      return await ApiService.get(`/donors/${donorId}`);
    } catch (error) {
      console.error('Error fetching donor by ID:', error);
      throw error;
    }
  }

  // Get donor by phone number
  async getDonorByPhone(phoneNumber) {
    try {
      return await ApiService.get(`/donors/phone/${phoneNumber}`);
    } catch (error) {
      console.error('Error fetching donor by phone:', error);
      throw error;
    }
  }

  // Update donor FCM token
  async updateFcmToken(donorId, fcmToken) {
    try {
      const params = { fcmToken };
      return await ApiService.put(`/donors/${donorId}/fcm-token`, null, { params });
    } catch (error) {
      console.error('Error updating FCM token:', error);
      throw error;
    }
  }

  // Update donor profile
  async updateDonorProfile(donorId, updateData) {
    try {
      const payload = {
        name: updateData.name,
        age: updateData.age ? parseInt(updateData.age) : null,
        gender: updateData.gender,
        bloodType: updateData.bloodType,
        phone: updateData.phone,
        email: updateData.email,
        address: updateData.address,
        weight: updateData.weight ? parseFloat(updateData.weight) : null
      };
      // Note: This endpoint might not exist in your current API
      // You may need to add it to your Spring Boot backend
      return await ApiService.put(`/donors/${donorId}`, payload);
    } catch (error) {
      console.error('Error updating donor profile:', error);
      throw error;
    }
  }

  // Check donor eligibility
  async checkDonorEligibility(donorId) {
    try {
      // Note: This endpoint might not exist in your current API
      // You may need to add it to your Spring Boot backend
      return await ApiService.get(`/donors/${donorId}/eligibility`);
    } catch (error) {
      console.error('Error checking donor eligibility:', error);
      throw error;
    }
  }

  // Get donor donation history
  async getDonorHistory(donorId) {
    try {
      // Note: This endpoint might not exist in your current API
      // You may need to add it to your Spring Boot backend
      return await ApiService.get(`/donors/${donorId}/history`);
    } catch (error) {
      console.error('Error fetching donor history:', error);
      throw error;
    }
  }

  // Search donors by criteria
  async searchDonors(criteria) {
    try {
      const params = {
        bloodType: criteria.bloodType,
        location: criteria.location,
        eligibilityStatus: criteria.eligibilityStatus
      };
      // Note: This endpoint might not exist in your current API
      // You may need to add it to your Spring Boot backend
      return await ApiService.get('/donors/search', params);
    } catch (error) {
      console.error('Error searching donors:', error);
      throw error;
    }
  }
}

export default new DonorService();


